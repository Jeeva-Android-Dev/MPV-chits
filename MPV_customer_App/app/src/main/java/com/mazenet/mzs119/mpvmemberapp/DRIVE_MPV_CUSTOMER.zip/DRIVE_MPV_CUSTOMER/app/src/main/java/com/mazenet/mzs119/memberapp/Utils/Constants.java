package com.mazenet.mzs119.memberapp.Utils;

public class Constants {
  //  static String loginurl = "http://www.mpvchitfunds.in/app/Mobile/MemberAPP/";
  static String loginurl = "http://www.mpvchitfunds.in/app_test/Mobile/MemberAPP/";

  //  static String loginurl = "http://essveeteexpress.com/app/Mobile/MemberAPP/";
    public static String preference = "MemberModule";



    public static final String CHANNEL_ID = "my_channel_01";
    public static final String CHANNEL_NAME = "Simplified Coding Notification";
    public static final String CHANNEL_DESCRIPTION = "www.simplifiedcoding.net";


    public static String login = loginurl + "logincustomer.php?";
    public static String getotp = loginurl + "sendotp.php?";
    public static String approvecustomer = loginurl + "approvecustomer.php?";
    public static String changepasswordfirst = loginurl + "changepassword.php?";
    public static String signup = loginurl + "signupcustomer.php?";
    public static String reteriveenroll = loginurl + "reteriveenroll.php?";  //*****
    public static String getprofile = loginurl + "reteriveindividualuser.php?";//****
    public static String retrieveaccountcopy = loginurl + "retrieveaccountcopy.php?";//*****
    public static String reteriveoutstanding = loginurl + "reteriveoutstanding.php?";
    public static String reterivenewchits = loginurl + "getnewcommenced.php";
    public static String reterivereceipts = loginurl + "mychittrans.php?";
    public static String sendinterest = loginurl + "sendinterest.php?";
    public static String availableadvance = loginurl + "getadvanceavailable.php?";
}

