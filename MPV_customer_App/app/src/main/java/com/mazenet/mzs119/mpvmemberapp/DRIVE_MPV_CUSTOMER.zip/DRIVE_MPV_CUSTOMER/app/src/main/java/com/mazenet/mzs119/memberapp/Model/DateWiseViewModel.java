package com.mazenet.mzs119.memberapp.Model;

/**
 * Created by MZS119 on 3/30/2018.
 */

public class DateWiseViewModel {
    String Cust_Id;
    String Enrl_Id;
    String Cus_Branch;
    String Total_Amount;
    String Receipt_No;
    String Created_By;
    String Cheque_No;
    String Cheque_Date;

    public String getDateitme() {
        return dateitme;
    }

    public void setDateitme(String dateitme) {
        this.dateitme = dateitme;
    }

    String dateitme;
String Date;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    String time;
String due_advance;

    public String getDue_advance() {
        return due_advance;
    }

    public void setDue_advance(String due_advance) {
        this.due_advance = due_advance;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getCust_Id() {
        return Cust_Id;
    }

    public void setCust_Id(String cust_Id) {
        Cust_Id = cust_Id;
    }

    public String getEnrl_Id() {
        return Enrl_Id;
    }

    public void setEnrl_Id(String enrl_Id) {
        Enrl_Id = enrl_Id;
    }

    public String getCus_Branch() {
        return Cus_Branch;
    }

    public void setCus_Branch(String cus_Branch) {
        Cus_Branch = cus_Branch;
    }

    public String getTotal_Amount() {
        return Total_Amount;
    }

    public void setTotal_Amount(String total_Amount) {
        Total_Amount = total_Amount;
    }

    public String getReceipt_No() {
        return Receipt_No;
    }

    public void setReceipt_No(String receipt_No) {
        Receipt_No = receipt_No;
    }

    public String getCreated_By() {
        return Created_By;
    }

    public void setCreated_By(String created_By) {
        Created_By = created_By;
    }

    public String getCheque_No() {
        return Cheque_No;
    }

    public void setCheque_No(String cheque_No) {
        Cheque_No = cheque_No;
    }

    public String getCheque_Date() {
        return Cheque_Date;
    }

    public void setCheque_Date(String cheque_Date) {
        Cheque_Date = cheque_Date;
    }

    public String getBank_Name() {
        return Bank_Name;
    }

    public void setBank_Name(String bank_Name) {
        Bank_Name = bank_Name;
    }

    public String getBranch_Name() {
        return Branch_Name;
    }

    public void setBranch_Name(String branch_Name) {
        Branch_Name = branch_Name;
    }

    public String getTrn_No() {
        return Trn_No;
    }

    public void setTrn_No(String trn_No) {
        Trn_No = trn_No;
    }

    public String getTrn_Date() {
        return Trn_Date;
    }

    public void setTrn_Date(String trn_Date) {
        Trn_Date = trn_Date;
    }

    public String getPayment_Type() {
        return Payment_Type;
    }

    public void setPayment_Type(String payment_Type) {
        Payment_Type = payment_Type;
    }

    public String getGroup_Id() {
        return Group_Id;
    }

    public void setGroup_Id(String group_Id) {
        Group_Id = group_Id;
    }

    public String getGroup_Ticket_Id() {
        return Group_Ticket_Id;
    }

    public void setGroup_Ticket_Id(String group_Ticket_Id) {
        Group_Ticket_Id = group_Ticket_Id;
    }

    public String getFirst_Name_F() {
        return First_Name_F;
    }

    public void setFirst_Name_F(String first_Name_F) {
        First_Name_F = first_Name_F;
    }

    public String getPending_Amt() {
        return Pending_Amt;
    }

    public void setPending_Amt(String pending_Amt) {
        Pending_Amt = pending_Amt;
    }

    public String getTotal_Enrl_Paid() {
        return Total_Enrl_Paid;
    }

    public void setTotal_Enrl_Paid(String total_Enrl_Paid) {
        Total_Enrl_Paid = total_Enrl_Paid;
    }

    public String getTotal_Enrl_Pending() {
        return Total_Enrl_Pending;
    }

    public void setTotal_Enrl_Pending(String total_Enrl_Pending) {
        Total_Enrl_Pending = total_Enrl_Pending;
    }

    public String getAdvance_Amt() {
        return Advance_Amt;
    }

    public void setAdvance_Amt(String advance_Amt) {
        Advance_Amt = advance_Amt;
    }

    String Bank_Name;
    String Branch_Name;
    String Trn_No;
    String Trn_Date;
    String Payment_Type;
    String Group_Id;
    String Group_Ticket_Id;
    String First_Name_F;
    String Pending_Amt;
    String Total_Enrl_Paid;
    String Total_Enrl_Pending;
    String Advance_Amt;
}
