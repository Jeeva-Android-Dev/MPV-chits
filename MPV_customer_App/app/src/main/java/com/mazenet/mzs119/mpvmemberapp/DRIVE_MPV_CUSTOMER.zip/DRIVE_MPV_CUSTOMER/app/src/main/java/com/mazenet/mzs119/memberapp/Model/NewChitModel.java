package com.mazenet.mzs119.memberapp.Model;

import com.android.volley.toolbox.StringRequest;

public class NewChitModel {

    String id,chitvalue,Month,Monthly_Amt,Scheme_Format;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChitvalue() {
        return chitvalue;
    }

    public void setChitvalue(String chitvalue) {
        this.chitvalue = chitvalue;
    }

    public String getMonth() {
        return Month;
    }

    public void setMonth(String month) {
        Month = month;
    }

    public String getMonthly_Amt() {
        return Monthly_Amt;
    }

    public void setMonthly_Amt(String monthly_Amt) {
        Monthly_Amt = monthly_Amt;
    }

    public String getScheme_Format() {
        return Scheme_Format;
    }

    public void setScheme_Format(String scheme_Format) {
        Scheme_Format = scheme_Format;
    }
}
